# قالب تطبيق RosTrick (Android)

مشروع Android Studio جاهز يبنيه GitHub Actions. لا تُعدّل `app/build.gradle` أو الألوان أو الاسم يدوياً؛
`tools/apply_config.py` يطبّق إعدادات اللوحة (`rostrick-build/config.json`) وقت البناء.

- `user-repo-files/build-apk.yml` ← تنسخه اللوحة إلى `.github/workflows/` في مستودع المستخدم.
- يجب أن يكون هذا المستودع **عاماً** (الـ workflow في مستودع المستخدم يستنسخه).
- التوقيع: مفتاح PKCS12 لكل مستخدم في Secrets (`RT_KEYSTORE_B64`, `RT_KEYSTORE_PASSWORD`) تنشئه اللوحة.
