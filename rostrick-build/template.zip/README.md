# قالب تطبيق RosTrick (Android)

مشروع Android Studio جاهز يبنيه GitHub Actions. لا تُعدّل `app/build.gradle` أو الألوان أو الاسم يدوياً؛
`tools/apply_config.py` يطبّق إعدادات اللوحة (`rostrick-build/config.json`) وقت البناء.

- `user-repo-files/build-apk.yml` ← تنسخه اللوحة إلى `.github/workflows/` في مستودع المستخدم.
- يجب أن يكون هذا المستودع **عاماً** (الـ workflow في مستودع المستخدم يستنسخه).
- التوقيع: مفتاح PKCS12 لكل مستخدم في Secrets (`RT_KEYSTORE_B64`, `RT_KEYSTORE_PASSWORD`) تنشئه اللوحة.

## ميزات اختيارية/دائمة (واجهات الصفحات)
- `RosTrickShare` — مشاركة نص/رابط/ملف عبر قائمة النظام (دائماً، مع `RtShareProvider`).
- `RosTrickReview` — `config.review.enabled` لنافذة التقييم (`RtReviewReal.java.txt`)، و`openStore()` دائماً.
- `RosTrickLinks` — `config.deeplinks = {enabled, scheme, hosts[], verify}` يضيف intent-filters داخل `SplashActivity` ويجعل `MainActivity` singleTask.

### assetlinks.json (الروابط العميقة المتحقَّق منها)
عند تفعيل `deeplinks.verify` مع نطاق واحد على الأقل، يولّد الـ workflow ملف `assetlinks.json` (اسم الحزمة + بصمة SHA-256 لمفتاح التوقيع + `deeplinks.extra_fingerprints` الاختيارية) ويحفظه في `rostrick-build/assetlinks.json` ويرفقه بملفات الـ Release.

## الصفحات اليدوية والزر متعدد الملفات
- `RosTrickPages.download/isDownloaded/openPage` تعمل لأي مسار (html/css/js/json/zip).
- `<button onCreate="rostrickpages" rostrick="a.html,b.css,c.js,d.json" rtnd="تحميل" rtid="دخول" progress="true">`: عدّة ملفات مفصولة بفاصلة؛ يُنزَّل الناقص فقط والنسبة عامة، وعند الاكتمال يتحول لـ `rtid` ويفتح أول ملف html (أو أول ملف). الحدث `rtpages` يحمل `path` و`paths`.

## العمل في الخلفية (اختياري — يُفعَّل من اللوحة، غير موجود في الـ Manifest افتراضياً)
`config.permissions` يقبل المفتاحين `bg_service` و`bg_scheduler` (`tools/apply_config.py` → `PERMISSION_CATALOG`):
- `bg_service`: خدمة أمامية `RtBackgroundService` (النوع `specialUse`) بإشعار دائم + زر إيقاف، تُعاد بعد إعادة التشغيل. اختيارياً تشغّل صفحة خلفية مخفية (WebView بلا واجهة) من ملف في ملفات التطبيق (واجهتها `window.RosTrickBg.notify/schedule/cancel/stop`).
- `bg_scheduler`: منبّهات `AlarmManager` (`RtAlarmReceiver`) تعرض إشعاراً في وقت محدد وتُعاد جدولتها بعد الإقلاع (`RtBootReceiver`). الإذن `SCHEDULE_EXACT_ALARM` يمنحه المستخدم من الإعدادات على Android 14+، وبدونه تعمل غير دقيقة.
- الواجهة للصفحات: `RosTrickBackground.available() / service.start({title,text,page,open}) / service.stop() / service.isRunning() / schedule({id,at|in,repeat,title,text,page,exact}) / cancel(id) / cancelAll() / list() / requestNotifications() / requestExactAlarms()`.
- يخفي/يُظهر خياريهما في اللوحة `settings.json → background_features {service, scheduler}` من theme manager.

## التحليلات (Google Analytics) — اختيارية
- `analytics: {enabled, ga4: {enabled, measurement_id, api_secret}, firebase}` في config.json؛ المعطّل = نسخة فارغة `RtAnalytics.java` بلا اتصال ولا مكتبة.
- **GA4 بدون مكتبة**: `tools/RtAnalyticsReal.java.txt` يرسل الأحداث عبر Measurement Protocol (`https://www.google-analytics.com/mp/collect`)، بمعرّف `G-…` وسر API (يُدمج في التطبيق).
- **Firebase Analytics**: يتطلب `firebase.enabled` (نفس google-services.json) ويضيف `firebase-analytics` بين `// RT-FA:START/END` في app/build.gradle.
- الصفحات: `window.RosTrickAnalytics` (`logEvent/screen/setUserId/setUserProperty/setEnabled/isEnabled/enabled`)؛ التطبيق يرسل تلقائياً `app_open` و`screen_view`.
- يخفي/يُظهر خياريهما في اللوحة `settings.json → analytics_features {ga4, firebase}` من theme manager.

## تحديث الصفحات اليدوية المحمّلة
- المقارنة: `timestamp` الصفحة في `app_lazy_pages.json` (تحدّثه اللوحة مع كل حفظ) مقابل التاريخ المسجّل وقت تنزيلها (SharedPreferences `rt_lazy_pages`).
- الافتراضي: عند تشغيل التطبيق يحدّث الصفحات اليدوية المحمّلة القديمة صامتاً. الأزرار `rtupdate="نص"` تسأل: تتحول الحالة إلى `update` ويُعاد تنزيل كامل القائمة بالضغط.
- جسر JS: `RosTrickPages.isOutdated(p)` و`refresh()` و`setAsk(p, bool)`.
