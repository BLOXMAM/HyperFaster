package com.createdby.rostrick;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import com.createdby.rostrick.databinding.*;
import com.scottyab.rootbeer.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SplashActivity extends Activity {
	
	private SplashBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = SplashBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		com.scottyab.rootbeer.RootBeer rootBeer = new com.scottyab.rootbeer.RootBeer(SplashActivity.this);
		
		if (rootBeer.isRooted()) {
			// تم اكتشاف روت، إيقاف التطبيق تماماً
			new android.app.AlertDialog.Builder(SplashActivity.this)
			.setTitle(RtI18n.t("تنبيه أمني ⚠️", "Security alert ⚠️"))
			.setMessage(RtI18n.t("عذراً، لا يمكن تشغيل التطبيق على أجهزة تحتوي على صلاحيات الروت لأسباب تتعلق بالأمان.", "Sorry, the app cannot run on rooted devices for security reasons."))
			.setCancelable(false)
			.setPositiveButton(RtI18n.t("إغلاق التطبيق", "Close app"), new android.content.DialogInterface.OnClickListener() {
				@Override
				public void onClick(android.content.DialogInterface dialog, int which) {
					finishAffinity(); // إغلاق التطبيق من الجذور
				}
			})
			.show();
			return; // إيقاف إكمال أي كود تالٍ في الـ Splash
		}
		
		// إذا كان الجهاز سليماً، انتقل إلى MainActivity بشكل طبيعي
		android.content.Intent intent = new android.content.Intent(SplashActivity.this, MainActivity.class);
		// RosTrick: إشعار Firebase فيه صفحة مطلوبة (rt_page) -> نمرّرها لـ MainActivity لتفتحها
		String rtPage = null;
		try {
			rtPage = getIntent() != null ? getIntent().getStringExtra("rt_page") : null;
		} catch (Throwable ignored) {}
		// RosTrick: رابط عميق (Deep Link) بصيغة  <applicationId>://<صفحة>  أو  <applicationId>://<صفحة>/<مسار>
		// -> نحوّله لنفس آلية rt_page أعلاه (نفس المتصفَّح من الإشعارات) بدون أي نظام مستقل
		try {
			android.content.Intent inIntent = getIntent();
			if ((rtPage == null || rtPage.length() == 0) && inIntent != null && android.content.Intent.ACTION_VIEW.equals(inIntent.getAction())) {
				android.net.Uri deepData = inIntent.getData();
				if (deepData != null) {
					String host = deepData.getHost();
					String path = deepData.getPath();
					String deepPage = (host != null ? host : "") + (path != null ? path : "");
					while (deepPage.startsWith("/")) deepPage = deepPage.substring(1);
					if (deepPage.length() > 0) rtPage = deepPage;
				}
			}
		} catch (Throwable ignored) {}
		if (rtPage != null && rtPage.length() > 0) intent.putExtra("rt_page", rtPage);
		startActivity(intent);
		finish();
	}
	
}
