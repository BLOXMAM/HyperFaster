package com.createdby.rostrick;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.File;

/**
 * RosTrick: خدمة أمامية عامة (Foreground Service) تُبقي التطبيق حيّاً في الخلفية بإشعار دائم.
 * اختيارياً تُشغّل صفحة خلفية مخفية (WebView بلا واجهة) من ملفات التطبيق (مثلاً bg.html) لتنفيذ JavaScript في الخلفية.
 * تُشغَّل من الصفحة: RosTrickBackground.service.start({title,text,page}) وتُوقَف بـ .stop()
 * لا تعمل إلا إذا اختار صاحب التطبيق "bg_service" (فتُعلَن في AndroidManifest.xml).
 */
public class RtBackgroundService extends Service {
	static volatile boolean running = false;
	private static final int NOTIF_ID = 5101;
	static final String ACTION_STOP = "com.createdby.rostrick.RT_BG_STOP";

	private WebView bgView;
	private final Handler main = new Handler(Looper.getMainLooper());

	@Override public IBinder onBind(Intent intent) { return null; }

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if (intent != null && ACTION_STOP.equals(intent.getAction())) {
			RtBackground.prefs(this).edit().remove(RtBackground.K_SVC).apply();
			stopSelf();
			return START_NOT_STICKY;
		}
		JSONObject cfg = null;
		try {
			String fromIntent = intent == null ? null : intent.getStringExtra("cfg");
			String saved = fromIntent != null ? fromIntent : RtBackground.prefs(this).getString(RtBackground.K_SVC, null);
			cfg = saved != null ? new JSONObject(saved) : new JSONObject();
			if (fromIntent != null) RtBackground.prefs(this).edit().putString(RtBackground.K_SVC, fromIntent).apply();
		} catch (Throwable t) { cfg = new JSONObject(); }

		startAsForeground(cfg.optString("title", ""), cfg.optString("text", ""), RtBackground.safePage(cfg.optString("open", "")));
		running = true;
		String page = RtBackground.safePage(cfg.optString("page", ""));
		if (page.length() > 0) startBackgroundPage(page);
		return START_STICKY;   // لو قتلها النظام يعيد تشغيلها (والإعدادات محفوظة)
	}

	private void startAsForeground(String title, String text, String openPage) {
		RtBackground.ensureChannel(this, RtBackground.CH_SERVICE, RtI18n.t("الخدمة الخلفية", "Background service"), NotificationManager.IMPORTANCE_LOW);
		Notification.Builder b = (Build.VERSION.SDK_INT >= 26) ? new Notification.Builder(this, RtBackground.CH_SERVICE) : new Notification.Builder(this);
		int icon = getApplicationInfo().icon;
		b.setSmallIcon(icon != 0 ? icon : android.R.drawable.stat_notify_sync);
		b.setContentTitle(title.length() > 0 ? title : getApplicationInfo().loadLabel(getPackageManager()).toString());
		b.setContentText(text.length() > 0 ? text : RtI18n.t("التطبيق يعمل في الخلفية", "The app is running in the background"));
		b.setOngoing(true);
		b.setContentIntent(RtBackground.openAppIntent(this, NOTIF_ID, openPage));
		Intent stop = new Intent(this, RtBackgroundService.class).setAction(ACTION_STOP);
		int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
		PendingIntent sp = PendingIntent.getService(this, NOTIF_ID + 1, stop, fl);   // getService (وليس getForegroundService) كي لا يُطلب startForeground عند الإيقاف
		b.addAction(android.R.drawable.ic_menu_close_clear_cancel, RtI18n.t("إيقاف", "Stop"), sp);
		Notification n = b.build();
		if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
		else startForeground(NOTIF_ID, n);
	}

	/** صفحة خلفية مخفية (بلا واجهة): ملف داخل ملفات التطبيق (مثل bg.html) أو رابط https. */
	private void startBackgroundPage(final String page) {
		main.post(new Runnable() {
			@Override public void run() {
				try {
					if (bgView != null) return;
					String url;
					if (page.startsWith("https://")) url = page;
					else {
						File f = new File(getFilesDir(), page);
						if (!f.exists() || f.length() == 0) return;
						url = "file://" + f.getAbsolutePath();
					}
					bgView = new WebView(getApplicationContext());
					WebSettings s = bgView.getSettings();
					s.setJavaScriptEnabled(true);
					s.setDomStorageEnabled(true);
					s.setAllowFileAccess(true);
					s.setMediaPlaybackRequiresUserGesture(false);
					bgView.addJavascriptInterface(new BgBridge(), "RosTrickBg");
					bgView.resumeTimers();
					bgView.onResume();
					bgView.loadUrl(url);
				} catch (Throwable t) { t.printStackTrace(); }
			}
		});
	}

	/** الواجهة المتاحة داخل الصفحة الخلفية: window.RosTrickBg */
	private class BgBridge {
		@android.webkit.JavascriptInterface
		public void notify(String title, String text, String page) {
			RtBackground.showNotification(RtBackgroundService.this, "bg" + System.currentTimeMillis(), title, text, RtBackground.safePage(page));
		}
		@android.webkit.JavascriptInterface
		public boolean schedule(String json) {
			try { return RtBackground.schedulerDeclared(RtBackgroundService.this) && RtBackground.schedule(RtBackgroundService.this, new JSONObject(json)); } catch (Throwable t) { return false; }
		}
		@android.webkit.JavascriptInterface
		public void cancel(String id) { if (RtBackground.schedulerDeclared(RtBackgroundService.this)) RtBackground.cancel(RtBackgroundService.this, id); }
		@android.webkit.JavascriptInterface
		public void stop() {
			RtBackground.prefs(RtBackgroundService.this).edit().remove(RtBackground.K_SVC).apply();
			main.post(new Runnable() { @Override public void run() { stopSelf(); } });
		}
	}

	@Override
	public void onDestroy() {
		running = false;
		try { if (bgView != null) { bgView.stopLoading(); bgView.destroy(); bgView = null; } } catch (Throwable ignored) {}
		super.onDestroy();
	}
}
