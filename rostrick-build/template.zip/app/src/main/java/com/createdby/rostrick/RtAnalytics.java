package com.createdby.rostrick;

import android.content.Context;

/**
 * نسخة فارغة من التحليلات (لا Google Analytics ولا Firebase Analytics).
 * عند تفعيل "التحليلات" في إعدادات البناء يستبدلها tools/apply_config.py بالنسخة الحقيقية من tools/RtAnalyticsReal.java.txt.
 */
final class RtAnalytics {
	static final boolean ENABLED = false;

	RtAnalytics(Context ctx) {}
	void appOpen() {}
	void screen(String name) {}
	boolean logEvent(String name, String paramsJson) { return false; }
	void setUserId(String id) {}
	void setUserProperty(String key, String value) {}
	void setEnabled(boolean on) {}
	boolean isEnabled() { return false; }
}
