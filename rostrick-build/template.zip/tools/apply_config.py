#!/usr/bin/env python3
"""
يطبّق إعدادات اللوحة (rostrick-build/config.json) على مشروع الأندرويد قبل البناء:
  - اسم التطبيق، applicationId، versionCode، versionName
  - ألوان الثيم
  - أيقونة التطبيق (تُولَّد منها كل الأحجام)
  - رابط الـ Worker داخل: final String ASSET_BASE_HOST = ... (يُستبدل بثابت Base64)

الاستخدام:
  python3 tools/apply_config.py --config <config.json> --project <مجلد المشروع> [--icon <icon.png>]
"""
import argparse
import base64
import json
import os
import re
import sys

JAVA_KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
    "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
    "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
    "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
    "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
    "volatile", "while", "true", "false", "null",
}

DEFAULT_COLORS = {
    "primary": "#000000",
    "primary_dark": "#000000",
    "accent": "#000090",
    "highlight": "#000090",
    "control_normal": "#000090",
}

ICON_SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}


def fail(msg):
    print("::error::" + msg)
    sys.exit(1)


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def validate_package(pkg):
    if not isinstance(pkg, str) or not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", pkg):
        fail("اسم الحزمة غير صالح: %r (مثال صحيح: com.mycompany.myapp، أحرف إنجليزية صغيرة وأرقام و _ فقط، وجزءان على الأقل)" % (pkg,))
    for part in pkg.split("."):
        if part in JAVA_KEYWORDS:
            fail("اسم الحزمة يحتوي كلمة محجوزة في Java: " + part)
    if pkg.startswith("android.") or pkg.startswith("com.android."):
        fail("اسم الحزمة محجوز للنظام: " + pkg)
    if len(pkg) > 150:
        fail("اسم الحزمة طويل جداً")


def validate_color(name, value):
    if not isinstance(value, str) or not re.fullmatch(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})", value):
        fail("لون %s غير صالح: %r (استخدم #RRGGBB)" % (name, value))
    return value.upper()


def clean_host(raw):
    host = (raw or "").strip()
    host = re.sub(r"^https?://", "", host, flags=re.I).strip("/ ")
    host = host.split("/")[0]
    if host and not re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?", host):
        fail("رابط الـ Worker غير صالح: %r" % raw)
    return host


def xml_escape_text(s):
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    s = s.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
    s = s.replace("\n", " ")
    if s[:1] in ("@", "?"):
        s = "\\" + s
    return s


def apply_colors(project, colors):
    c = dict(DEFAULT_COLORS)
    c.update({k: v for k, v in (colors or {}).items() if k in DEFAULT_COLORS and v})
    c = {k: validate_color(k, v) for k, v in c.items()}
    xml = (
        "<resources>\n"
        '\t<color name="colorPrimary">%(primary)s</color>\n'
        '\t<color name="colorPrimaryDark">%(primary_dark)s</color>\n'
        '\t<color name="colorAccent">%(accent)s</color>\n'
        '\t<color name="colorControlHighlight">%(highlight)s</color>\n'
        '\t<color name="colorControlNormal">%(control_normal)s</color>\n'
        "</resources>\n"
    ) % c
    write(os.path.join(project, "app/src/main/res/values/colors.xml"), xml)


def apply_strings(project, app_name):
    name = (app_name or "").strip()
    if not name:
        fail("اسم التطبيق فارغ")
    if len(name) > 60:
        fail("اسم التطبيق طويل جداً (الحد 60 حرفاً)")
    xml = (
        "<resources>\n"
        '\t<string name="app_name" translatable="false">%s</string>\n'
        "</resources>\n"
    ) % xml_escape_text(name)
    write(os.path.join(project, "app/src/main/res/values/strings.xml"), xml)


MIN_SDK_RANGE = (21, 36)
TARGET_SDK_RANGE = (23, 36)   # أندرويد 14+ يرفض تثبيت تطبيقات تستهدف أقل من 23


def resolve_sdk(cfg):
    """min_sdk (أدنى إصدار أندرويد يعمل عليه التطبيق) و target_sdk (الإصدار المستهدف). الافتراضي 21 و 36."""
    out = []
    for key, default, (lo, hi), label in (("min_sdk", 21, MIN_SDK_RANGE, "الحد الأدنى"), ("target_sdk", 36, TARGET_SDK_RANGE, "المستهدف")):
        raw = cfg.get(key)
        if raw in (None, ""):
            out.append(default)
            continue
        try:
            v = int(raw)
        except (TypeError, ValueError):
            fail("%s (%s) يجب أن يكون رقماً صحيحاً" % (key, label))
        if not (lo <= v <= hi):
            fail("%s (%s) خارج النطاق المسموح %d – %d" % (key, label, lo, hi))
        out.append(v)
    if out[0] > out[1]:
        fail("الحد الأدنى لـ SDK (%d) أكبر من المستهدف (%d)" % (out[0], out[1]))
    return out[0], out[1]


def apply_gradle(project, pkg, version_code, version_name, min_sdk=21, target_sdk=36):
    path = os.path.join(project, "app/build.gradle")
    g = read(path)
    g, n4 = re.subn(r"minSdkVersion\s+\d+", "minSdkVersion %d" % min_sdk, g, count=1)
    g, n5 = re.subn(r"targetSdkVersion\s+\d+", "targetSdkVersion %d" % target_sdk, g, count=1)
    if (n4, n5) != (1, 1):
        fail("تعذّر تعديل minSdkVersion/targetSdkVersion في app/build.gradle")
    g, n1 = re.subn(r'applicationId\s+"[^"]*"', 'applicationId "%s"' % pkg, g, count=1)
    g, n2 = re.subn(r"versionCode\s+\d+", "versionCode %d" % version_code, g, count=1)
    g, n3 = re.subn(r'versionName\s+"[^"]*"', 'versionName "%s"' % version_name.replace('"', ""), g, count=1)
    if (n1, n2, n3) != (1, 1, 1):
        fail("تعذّر تعديل app/build.gradle (لم أجد applicationId/versionCode/versionName)")
    write(path, g)


def _java_obf(text):
    """يرمّز النص بـ Base64 كثابت واحد، يُفك وقت التشغيل (مع ProGuard/R8 هذا كافٍ)."""
    b64 = base64.b64encode(text.encode("utf-8")).decode("ascii")
    return ('new String(android.util.Base64.decode("%s", android.util.Base64.DEFAULT))'
             % b64)


def apply_worker_host(project, host):
    java_dir = os.path.join(project, "app/src/main/java")
    pattern = re.compile(r'final String ASSET_BASE_HOST = "[^"]*";')
    pages = re.compile(r'final String APP_PAGES_URL = ASSET_BASE_URL \+ "apppages\.json";')
    total = 0
    for root, _, files in os.walk(java_dir):
        for fn in files:
            if not fn.endswith(".java"):
                continue
            p = os.path.join(root, fn)
            src = read(p)
            new, n = pattern.subn(lambda m: "final String ASSET_BASE_HOST = %s;" % _java_obf(host), src)
            new, _ = pages.subn(lambda m: "final String APP_PAGES_URL = ASSET_BASE_URL + %s;" % _java_obf("apppages.json"), new)
            if n:
                write(p, new)
                total += n
    if total != 1:
        fail("توقعت وجود تعريف ASSET_BASE_HOST مرة واحدة بالضبط، وجدت %d" % total)


def apply_icon(project, icon_path):
    if not icon_path or not os.path.isfile(icon_path):
        print("لا توجد أيقونة مخصصة، سيُستخدم الافتراضي.")
        return
    try:
        from PIL import Image
    except ImportError:
        fail("مكتبة Pillow غير مثبتة")
    try:
        img = Image.open(icon_path).convert("RGBA")
    except Exception as e:  # noqa: BLE001
        fail("تعذّر قراءة ملف الأيقونة: %s" % e)
    w, h = img.size
    side = max(w, h)
    if side < 96:
        fail("الأيقونة صغيرة جداً (%dx%d)، الحد الأدنى 96x96 والمستحسن 512x512" % (w, h))
    if w != h:  # نضعها في مربع شفاف بدل تشويهها
        square = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        square.paste(img, ((side - w) // 2, (side - h) // 2))
        img = square
    res = os.path.join(project, "app/src/main/res")
    for d in os.listdir(res):
        if d.startswith("mipmap-"):
            old = os.path.join(res, d, "ic_launcher.png")
            if os.path.exists(old):
                os.remove(old)
    for density, px in ICON_SIZES.items():
        out = os.path.join(res, "mipmap-" + density, "ic_launcher.png")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        img.resize((px, px), Image.LANCZOS).save(out, "PNG", optimize=True)
    print("تم توليد الأيقونة بالأحجام:", ", ".join(ICON_SIZES))


ADAPTIVE_DENSITIES = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
ADAPTIVE_CANVAS_DP = 108      # حجم طبقة الأيقونة التكيّفية
ADAPTIVE_ART_DP = 72          # المنطقة التي توضع فيها الصورة (المنطقة الآمنة 66dp تبقى كاملة الظهور)


def auto_icon_background(img):
    """لون خلفية تلقائي: متوسط ألوان حواف الصورة (مرجّحاً بالشفافية). إن كانت الحواف شفافة غالباً → أبيض."""
    w, h = img.size
    t = max(1, round(min(w, h) * 0.02))
    px = img.convert("RGBA").load()
    sr = sg = sb = sa = 0
    n = 0
    for y in range(h):
        edge_row = y < t or y >= h - t
        xs = range(w) if edge_row else list(range(0, t)) + list(range(w - t, w))
        for x in xs:
            r, g, b, a = px[x, y]
            n += 1
            sr += r * a
            sg += g * a
            sb += b * a
            sa += a
    if n == 0 or sa / (255.0 * n) < 0.5:
        return "#FFFFFF"
    return "#%02X%02X%02X" % (round(sr / sa), round(sg / sa), round(sb / sa))


def apply_adaptive_icon(project, icon_path, cfg):
    """أيقونة تكيّفية (أندرويد 8+): الصورة كطبقة أمامية ولون خلفية، فيقصّها قاذف الأجهزة بالشكل الذي يريده
    (دائرة/مربع مدوّر...) دون مربع أبيض. الإصدارات الأقدم تبقى على أيقونة PNG التقليدية المولَّدة سابقاً.
    cfg.icon_style: "adaptive" (الافتراضي) أو "plain". cfg.icon_bg: "#RRGGBB" أو فارغ = تلقائي.
    يرجع (الأسلوب المطبّق، لون الخلفية)."""
    style = cfg.get("icon_style") or "adaptive"
    if style not in ("adaptive", "plain"):
        fail("icon_style غير صالح: %r (adaptive أو plain)" % (style,))
    if not icon_path or not os.path.isfile(icon_path) or style == "plain":
        return "plain", ""
    from PIL import Image
    img = Image.open(icon_path).convert("RGBA")
    w, h = img.size
    side = max(w, h)
    if w != h:
        sq = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        sq.paste(img, ((side - w) // 2, (side - h) // 2))
        img = sq
    bg = (cfg.get("icon_bg") or "").strip()
    if bg:
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", bg):
            fail("لون خلفية الأيقونة غير صالح: %r (استخدم #RRGGBB)" % (bg,))
        bg = bg.upper()
    else:
        bg = auto_icon_background(img)
    res = os.path.join(project, "app/src/main/res")
    for density, scale in ADAPTIVE_DENSITIES.items():
        canvas_px = round(ADAPTIVE_CANVAS_DP * scale)
        art_px = round(ADAPTIVE_ART_DP * scale)
        canvas = Image.new("RGBA", (canvas_px, canvas_px), (0, 0, 0, 0))
        art = img.resize((art_px, art_px), Image.LANCZOS)
        off = (canvas_px - art_px) // 2
        canvas.paste(art, (off, off), art)
        out = os.path.join(res, "drawable-" + density, "ic_launcher_foreground.png")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        canvas.save(out, "PNG", optimize=True)
    write(os.path.join(res, "values/ic_launcher_background.xml"),
          '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n\t<color name="ic_launcher_background">%s</color>\n</resources>\n' % bg)
    write(os.path.join(res, "mipmap-anydpi-v26/ic_launcher.xml"),
          '<?xml version="1.0" encoding="utf-8"?>\n'
          '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
          '\t<background android:drawable="@color/ic_launcher_background" />\n'
          '\t<foreground android:drawable="@drawable/ic_launcher_foreground" />\n'
          '</adaptive-icon>\n')
    print("أيقونة تكيّفية: خلفية %s" % bg)
    return "adaptive", bg


def resolve_icon(cfg, icon_path, project):
    """الأيقونة تُرسل داخل config.json نفسه (icon_b64) فلا يمكن أن تختلف عن بقية الإعدادات:
    - icon_b64 نص → تُفك وتُستخدم
    - icon_b64 = null → الأيقونة الافتراضية (يُتجاهل أي icon.png قديم)
    - لا يوجد المفتاح (إعدادات قديمة) → icon.png إن وُجد
    يرجع (مسار الأيقونة أو "", sha256 مختصر)."""
    import base64
    import hashlib
    if "icon_b64" in cfg:
        raw = cfg.get("icon_b64")
        if not raw:
            print("الإعدادات: لا توجد أيقونة مخصصة → الأيقونة الافتراضية")
            return "", ""
        try:
            data = base64.b64decode(raw, validate=False)
        except Exception as e:  # noqa: BLE001
            fail("icon_b64 في config.json تالف: %s" % e)
        path = os.path.join(project, "icon_custom.png")
        with open(path, "wb") as f:
            f.write(data)
        print("الأيقونة من config.json: %d بايت" % len(data))
        return path, hashlib.sha256(data).hexdigest()[:12]
    if icon_path and os.path.isfile(icon_path):
        with open(icon_path, "rb") as f:
            data = f.read()
        return icon_path, hashlib.sha256(data).hexdigest()[:12]
    return "", ""


# أذونات أُزيلت من القائمة (صارت أساسية أو غير لازمة): تُتجاهل بصمت في الإعدادات القديمة
LEGACY_PERMISSIONS = {"vibrate", "wake_lock", "bluetooth"}

PERMISSION_CATALOG = {
    "camera": {
        "perms": ["android.permission.CAMERA"],
        "features": [("android.hardware.camera", False), ("android.hardware.camera.autofocus", False)],
    },
    "microphone": {
        "perms": ["android.permission.RECORD_AUDIO", "android.permission.MODIFY_AUDIO_SETTINGS"],
        "features": [("android.hardware.microphone", False)],
    },
    "location": {
        "perms": ["android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"],
        "features": [("android.hardware.location", False)],
    },
    "media_download": {
        # تنزيل الوسائط (فيديو/صوت) للتشغيل دون اتصال — خدمة نظام تعمل في الخلفية (Foreground Service).
        # هذا الأذن حسّاس: Google Play تطلب عند النشر فيديو يوضّح استخدامه فعلياً، لذلك يبقى معطّلاً
        # افتراضياً (لا يوجد في AndroidManifest.xml الأساسي) ولا يُضاف إلا إذا اختاره المستخدم صراحةً.
        "perms": ["android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_DATA_SYNC"],
        "features": [],
        "service": '\t\t<service\n\t\t\tandroid:name=".MediaDownloadService"\n\t\t\tandroid:enabled="true"\n\t\t\tandroid:exported="false"\n\t\t\tandroid:foregroundServiceType="dataSync" />',
    },
}


NATIVE_ASSETS_RESERVED = {"home.html", "404.html"}  # ملفات أساسية في جذر assets/ لا يجوز استبدالها


def apply_extra_assets(project, cfg):
    """يكتب الملفات الإضافية التي يرفعها المسؤول من قسم «ملفات إضافية داخل assets» في اللوحة
    (cfg.extra_assets = [{name, b64}, ...]) مباشرة داخل جذر app/src/main/assets/، فتُحقن في الـ APK
    الناتج وتكون متوفرة من أول تشغيل دون اتصال بالإنترنت. تُقرأ من كود الصفحة عبر:
    window.RosTrickAssets.read(name) / .exists(name)."""
    import base64

    items = cfg.get("extra_assets")
    if not items:
        print("ملفات إضافية داخل assets: لا شيء")
        return False
    if not isinstance(items, list):
        fail("extra_assets في config.json يجب أن تكون قائمة")

    target_dir = os.path.join(project, "app/src/main/assets")
    os.makedirs(target_dir, exist_ok=True)
    target_root = os.path.realpath(target_dir)
    count = 0
    for item in items:
        if not isinstance(item, dict):
            fail("عنصر غير صالح داخل extra_assets: %r" % (item,))
        name = str(item.get("name") or "").strip()
        b64 = item.get("b64")
        if not name or not b64:
            continue
        norm = os.path.normpath(name).replace("\\", "/")
        if norm.startswith("../") or norm.startswith("/") or norm == ".." or ":" in norm:
            fail("اسم ملف غير صالح داخل extra_assets: %r" % name)
        if norm.lower() in NATIVE_ASSETS_RESERVED:
            fail("لا يمكن استخدام الاسم %r في الملفات الإضافية — هذا اسم ملف أساسي محجوز في التطبيق" % name)
        dest = os.path.realpath(os.path.join(target_dir, norm))
        if os.path.commonpath([dest, target_root]) != target_root:
            fail("مسار غير صالح داخل extra_assets (خارج المجلد المسموح): %r" % name)
        try:
            data = base64.b64decode(b64, validate=False)
        except Exception as e:  # noqa: BLE001
            fail("محتوى الملف %r في extra_assets تالف: %s" % (name, e))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(data)
        count += 1

    print("ملفات إضافية داخل assets: %d ملف" % count)
    return count > 0


def apply_permissions(project, cfg):
    """يضيف الأذونات الاختيارية إلى AndroidManifest.xml (الأساسية موجودة أصلاً في القالب)."""
    chosen = cfg.get("permissions") or []
    if not isinstance(chosen, list):
        fail("حقل permissions في config.json يجب أن يكون قائمة")
    chosen = [c for c in chosen if c not in LEGACY_PERMISSIONS]
    unknown = [c for c in chosen if c not in PERMISSION_CATALOG]
    if unknown:
        fail("أذونات غير معروفة: " + ", ".join(map(str, unknown)))
    path = os.path.join(project, "app/src/main/AndroidManifest.xml")
    xml = read(path)
    xml = re.sub(r"[ \t]*<!-- RT-PERMS:START -->.*?<!-- RT-PERMS:END -->\n?", "", xml, flags=re.S)
    xml = re.sub(r"[ \t]*<!-- RT-SERVICES:START -->.*?<!-- RT-SERVICES:END -->\n?", "", xml, flags=re.S)
    if not chosen:
        write(path, xml)
        print("الأذونات الاختيارية: لا شيء")
        return
    lines = ["\t<!-- RT-PERMS:START -->"]
    service_lines = ["\t\t<!-- RT-SERVICES:START -->"]
    has_service = False
    seen = set(re.findall(r'<uses-permission[^>]*android:name="([^"]+)"', xml))
    for key in sorted(set(chosen)):
        info = PERMISSION_CATALOG[key]
        for pm in info["perms"]:
            name, max_sdk = (pm, None) if isinstance(pm, str) else pm
            if name in seen:
                continue
            seen.add(name)
            extra = ' android:maxSdkVersion="%d"' % max_sdk if max_sdk else ""
            if name == "android.permission.BLUETOOTH_SCAN":
                extra = ' android:usesPermissionFlags="neverForLocation"'
            lines.append('\t<uses-permission android:name="%s"%s />' % (name, extra))
        for feat, req in info["features"]:
            lines.append('\t<uses-feature android:name="%s" android:required="%s" />' % (feat, "true" if req else "false"))
        if info.get("service"):
            has_service = True
            service_lines.append(info["service"])
    lines.append("\t<!-- RT-PERMS:END -->")
    block = "\n".join(lines) + "\n"
    if "<application" not in xml:
        fail("لم أجد <application> في AndroidManifest.xml")
    xml = xml.replace("\t<application", block + "\t<application", 1)
    if has_service:
        service_lines.append("\t\t<!-- RT-SERVICES:END -->")
        service_block = "\n".join(service_lines) + "\n"
        if "\t</application>" not in xml:
            fail("لم أجد </application> في AndroidManifest.xml")
        xml = xml.replace("\t</application>", service_block + "\t</application>", 1)
    write(path, xml)
    print("الأذونات الاختيارية:", ", ".join(sorted(set(chosen))))


# معرّفات الاختبار الرسمية من Google (آمنة: النقر عليها لا يضرّ حسابك)
ADS_TEST = {
    "app": "ca-app-pub-3940256099942544~3347511713",
    "banner": "ca-app-pub-3940256099942544/6300978111",
    "interstitial": "ca-app-pub-3940256099942544/1033173712",
    "rewarded": "ca-app-pub-3940256099942544/5224354917",
}
ADS_MIN_SDK = 23   # مكتبة play-services-ads الحديثة تتطلب API 23 على الأقل


def ads_settings(cfg):
    """يقرأ ويتحقق من إعدادات الإعلانات. يرجع None إن كانت معطّلة."""
    ads = cfg.get("ads")
    if not isinstance(ads, dict) or not ads.get("enabled"):
        return None
    test = bool(ads.get("test_mode"))
    app_id = str(ads.get("app_id") or "").strip()
    ids = {k: str(ads.get(k + "_id") or "").strip() for k in ("banner", "interstitial", "rewarded")}
    if test:
        app_id = ADS_TEST["app"]
        ids = {k: ADS_TEST[k] for k in ids}
    else:
        if not re.fullmatch(r"ca-app-pub-\d{16}~\d{10}", app_id):
            fail("معرّف تطبيق AdMob غير صالح أو ناقص (الشكل: ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX)")
        for k, v in ids.items():
            if v and not re.fullmatch(r"ca-app-pub-\d{16}/\d{10}", v):
                fail("معرّف وحدة إعلانية (%s) غير صالح (الشكل: ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX)" % k)
        if not any(ids.values()):
            fail("الإعلانات مفعّلة لكن لا توجد أي وحدة إعلانية: أدخل واحدة على الأقل أو فعّل وضع الاختبار")
    return {"test": test, "app_id": app_id, "ids": ids}


def apply_ads(project, cfg):
    """يفعّل الإعلانات (AdMob) أو يتركها خارج التطبيق تماماً."""
    st = ads_settings(cfg)
    gradle_path = os.path.join(project, "app/build.gradle")
    manifest_path = os.path.join(project, "app/src/main/AndroidManifest.xml")
    java_path = os.path.join(project, "app/src/main/java/com/createdby/rostrick/RtAds.java")

    g = re.sub(r"[ \t]*// RT-ADS:START.*?// RT-ADS:END\n?", "", read(gradle_path), flags=re.S)
    m = re.sub(r"[ \t]*<!-- RT-ADS:START -->.*?<!-- RT-ADS:END -->\n?", "", read(manifest_path), flags=re.S)
    if st is None:
        write(gradle_path, g)
        write(manifest_path, m)
        print("الإعلانات: معطّلة (لا مكتبة إعلانات داخل التطبيق)")
        return False

    real = read(os.path.join(os.path.dirname(os.path.abspath(__file__)), "RtAdsReal.java.txt"))
    for key, ph in (("banner", "__RT_BANNER__"), ("interstitial", "__RT_INTERSTITIAL__"), ("rewarded", "__RT_REWARDED__")):
        real = real.replace(ph, st["ids"][key])
    if "__RT_" in real:
        fail("بقيت علامات غير مستبدلة في RtAdsReal.java.txt")
    write(java_path, real)

    dep = ('\t// RT-ADS:START\n'
           '\timplementation "com.google.android.gms:play-services-ads:${project.findProperty(\'adsVersion\') ?: \'24.4.0\'}"\n'
           '\t// RT-ADS:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة الإعلانات في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(gradle_path, g)

    meta = ('\t\t<!-- RT-ADS:START -->\n'
            '\t\t<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="%s" />\n'
            '\t\t<!-- RT-ADS:END -->\n') % st["app_id"]
    if "</application>" not in m:
        fail("لم أجد </application> في AndroidManifest.xml")
    m = m.replace("\t</application>", meta + "\t</application>", 1)
    write(manifest_path, m)
    print("الإعلانات (AdMob): مفعّلة (%s) | الوحدات: %s" % ("وضع الاختبار" if st["test"] else "حقيقية",
          ", ".join(k for k, v in st["ids"].items() if v)))
    return True


def unity_ads_settings(cfg):
    """يقرأ ويتحقق من إعدادات إعلانات Unity Ads. يرجع None إن كانت معطّلة.
    بخلاف AdMob: لا يوجد لدى Unity معرّف Placement تجريبي عام مضمون لكل الأنواع (البانر خاصة)،
    لذا تُطلب معرّفات حقيقية دائماً — وضع الاختبار هنا يمرَّر فقط كعلم testMode لتصنيف الإعلان غير فعلي."""
    ads = cfg.get("unity_ads")
    if not isinstance(ads, dict) or not ads.get("enabled"):
        return None
    test = bool(ads.get("test_mode"))
    game_id = str(ads.get("game_id") or "").strip()
    ids = {k: str(ads.get(k + "_id") or "").strip() for k in ("banner", "interstitial", "rewarded")}
    if not re.fullmatch(r"\d{3,12}", game_id):
        fail("معرّف لعبة Unity Ads (Game ID) غير صالح أو ناقص (أرقام فقط)")
    if not any(ids.values()):
        fail("إعلانات Unity مفعّلة لكن لا يوجد أي Placement ID: أدخل واحداً على الأقل (لا يوجد معرّف تجريبي عام مضمون لدى Unity)")
    return {"test": test, "game_id": game_id, "ids": ids}


def apply_unity_ads(project, cfg):
    """يفعّل إعلانات Unity Ads أو يتركها خارج التطبيق تماماً."""
    st = unity_ads_settings(cfg)
    gradle_path = os.path.join(project, "app/build.gradle")
    java_path = os.path.join(project, "app/src/main/java/com/createdby/rostrick/RtUnityAds.java")

    g = re.sub(r"[ \t]*// RT-UNITYADS:START.*?// RT-UNITYADS:END\n?", "", read(gradle_path), flags=re.S)
    if st is None:
        write(gradle_path, g)
        print("الإعلانات (Unity Ads): معطّلة (لا مكتبة إعلانات داخل التطبيق)")
        return False

    real = read(os.path.join(os.path.dirname(os.path.abspath(__file__)), "RtUnityAdsReal.java.txt"))
    real = real.replace("__RT_UNITY_GAMEID__", st["game_id"])
    real = real.replace("__RT_UNITY_TESTMODE__", "true" if st["test"] else "false")
    for key, ph in (("banner", "__RT_UNITY_BANNER__"), ("interstitial", "__RT_UNITY_INTERSTITIAL__"), ("rewarded", "__RT_UNITY_REWARDED__")):
        real = real.replace(ph, st["ids"][key])
    if "__RT_UNITY_" in real:
        fail("بقيت علامات غير مستبدلة في RtUnityAdsReal.java.txt")
    write(java_path, real)

    dep = ('\t// RT-UNITYADS:START\n'
           '\timplementation "com.unity3d.ads:unity-ads:${project.findProperty(\'unityAdsVersion\') ?: \'4.12.2\'}"\n'
           '\t// RT-UNITYADS:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة Unity Ads في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(gradle_path, g)
    print("الإعلانات (Unity Ads): مفعّلة (%s) | الوحدات: %s" % ("وضع الاختبار" if st["test"] else "حقيقية",
          ", ".join(k for k, v in st["ids"].items() if v)))
    return True


def fb_ads_settings(cfg):
    """يقرأ ويتحقق من إعدادات إعلانات Meta Audience Network (فيسبوك). يرجع None إن كانت معطّلة."""
    ads = cfg.get("facebook_ads")
    if not isinstance(ads, dict) or not ads.get("enabled"):
        return None
    test = bool(ads.get("test_mode"))
    ids = {k: str(ads.get(k + "_id") or "").strip() for k in ("banner", "interstitial", "rewarded")}
    # لا توجد لدى فيسبوك معرّفات Placement تجريبية عامة كـ AdMob: لا بد من معرّف حقيقي حتى في وضع الاختبار
    for k, v in ids.items():
        if v and not re.fullmatch(r"\d+_\d+", v):
            fail("معرّف Placement فيسبوك (%s) غير صالح (الشكل المتوقع: أرقام_أرقام)" % k)
    if not any(ids.values()):
        fail("إعلانات فيسبوك مفعّلة لكن لا يوجد أي Placement ID: أدخل واحداً على الأقل (لا يوجد معرّف تجريبي عام لدى فيسبوك)")
    return {"test": test, "ids": ids}


def apply_fb_ads(project, cfg):
    """يفعّل إعلانات Meta Audience Network (فيسبوك) أو يتركها خارج التطبيق تماماً."""
    st = fb_ads_settings(cfg)
    gradle_path = os.path.join(project, "app/build.gradle")
    java_path = os.path.join(project, "app/src/main/java/com/createdby/rostrick/RtFbAds.java")

    g = re.sub(r"[ \t]*// RT-FBADS:START.*?// RT-FBADS:END\n?", "", read(gradle_path), flags=re.S)
    if st is None:
        write(gradle_path, g)
        print("الإعلانات (فيسبوك): معطّلة (لا مكتبة إعلانات داخل التطبيق)")
        return False

    real = read(os.path.join(os.path.dirname(os.path.abspath(__file__)), "RtFbAdsReal.java.txt"))
    real = real.replace("__RT_FB_TESTMODE__", "true" if st["test"] else "false")
    for key, ph in (("banner", "__RT_FB_BANNER__"), ("interstitial", "__RT_FB_INTERSTITIAL__"), ("rewarded", "__RT_FB_REWARDED__")):
        real = real.replace(ph, st["ids"][key])
    if "__RT_FB_" in real:
        fail("بقيت علامات غير مستبدلة في RtFbAdsReal.java.txt")
    write(java_path, real)

    dep = ('\t// RT-FBADS:START\n'
           '\timplementation "com.facebook.android:audience-network-sdk:${project.findProperty(\'fbAdsVersion\') ?: \'6.19.0\'}"\n'
           '\t// RT-FBADS:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة فيسبوك للإعلانات في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(gradle_path, g)
    print("الإعلانات (فيسبوك): مفعّلة (%s) | الوحدات: %s" % ("وضع الاختبار" if st["test"] else "حقيقية",
          ", ".join(k for k, v in st["ids"].items() if v)))
    return True


JAVA_PKG_DIR = "app/src/main/java/com/createdby/rostrick"
STAT_ICON_XML = (
    '<?xml version="1.0" encoding="utf-8"?>\n'
    '<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
    '    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n'
    '    <path android:fillColor="#FFFFFFFF" android:pathData="M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.89,2 2,2zM18,16v-5c0,-3.07 -1.64,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.63,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2z"/>\n'
    '</vector>\n'
)


def firebase_settings(cfg, pkg):
    """يرجع نص google-services.json إن كان Firebase مفعّلاً (بعد التحقق)، وإلا None."""
    fb = cfg.get("firebase")
    if not isinstance(fb, dict) or not fb.get("enabled"):
        return None
    raw = str(fb.get("google_services_b64") or "").strip()
    if not raw:
        fail("Firebase مفعّل لكن ملف google-services.json غير مرفوع. ارفعه من قسم البناء أو أطفئ الخيار")
    try:
        text = base64.b64decode(raw).decode("utf-8")
        data = json.loads(text)
    except Exception:  # noqa: BLE001
        fail("ملف google-services.json تالف أو ليس JSON صالحاً")
    pkgs = []
    for c in data.get("client", []) if isinstance(data, dict) else []:
        try:
            pkgs.append(c["client_info"]["android_client_info"]["package_name"])
        except Exception:  # noqa: BLE001
            pass
    if pkg not in pkgs:
        fail("اسم الحزمة في RosTrick (%s) لا يطابق ملف google-services.json (الموجود: %s). أضف تطبيق أندرويد في Firebase بنفس اسم الحزمة ثم نزّل الملف من جديد"
             % (pkg, ", ".join(pkgs) or "لا شيء"))
    return text


def strip_marked(text, start, end):
    return re.sub(r"[ \t]*%s.*?%s\n?" % (re.escape(start), re.escape(end)), "", text, flags=re.S)


def apply_firebase(project, cfg, pkg):
    """يفعّل إشعارات Firebase (FCM) أو يتركها خارج التطبيق تماماً."""
    gs = firebase_settings(cfg, pkg)
    root_gradle = os.path.join(project, "build.gradle")
    app_gradle = os.path.join(project, "app/build.gradle")
    manifest = os.path.join(project, "app/src/main/AndroidManifest.xml")
    gs_path = os.path.join(project, "app/google-services.json")
    svc_path = os.path.join(project, JAVA_PKG_DIR, "RtMessagingService.java")
    icon_path = os.path.join(project, "app/src/main/res/drawable/ic_stat_rostrick.xml")

    rg = strip_marked(read(root_gradle), "// RT-FB:START", "// RT-FB:END")
    g = strip_marked(read(app_gradle), "// RT-FB:START", "// RT-FB:END")
    g = re.sub(r"\n[ \t]*id 'com\.google\.gms\.google-services'[^\n]*", "", g)
    m = strip_marked(read(manifest), "<!-- RT-FB:START -->", "<!-- RT-FB:END -->")
    for stale in (gs_path, svc_path, icon_path):
        if os.path.exists(stale):
            os.remove(stale)
    if gs is None:
        write(root_gradle, rg); write(app_gradle, g); write(manifest, m)
        print("Firebase: معطّل (لا مكتبة ولا خدمة إشعارات داخل التطبيق)")
        return False

    tools = os.path.dirname(os.path.abspath(__file__))
    write(os.path.join(project, JAVA_PKG_DIR, "RtPush.java"), read(os.path.join(tools, "RtPushReal.java.txt")))
    write(svc_path, read(os.path.join(tools, "RtMessagingService.java.txt")))
    os.makedirs(os.path.dirname(icon_path), exist_ok=True)
    write(icon_path, STAT_ICON_XML)
    write(gs_path, gs)

    anchor = re.search(r"^.*classpath 'com\.android\.tools\.build:gradle:[^']*'.*\n", rg, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد classpath لـ AGP في build.gradle الرئيسي")
    rg = rg[:anchor.end()] + "        // RT-FB:START\n        classpath 'com.google.gms:google-services:4.4.2'\n        // RT-FB:END\n" + rg[anchor.end():]
    write(root_gradle, rg)

    pl = re.search(r"^[ \t]*id 'com\.android\.application'.*\n", g, flags=re.M)
    if not pl:
        fail("تعذّر إيجاد plugins في app/build.gradle")
    g = g[:pl.end()] + "\tid 'com.google.gms.google-services'\n" + g[pl.end():]
    dep = ('\t// RT-FB:START\n'
           "\timplementation platform(\"com.google.firebase:firebase-bom:${project.findProperty('firebaseBomVersion') ?: '33.16.0'}\")\n"
           "\timplementation 'com.google.firebase:firebase-messaging'\n"
           '\t// RT-FB:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة Firebase في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)

    block = ('\t\t<!-- RT-FB:START -->\n'
             '\t\t<service android:name=".RtMessagingService" android:exported="false">\n'
             '\t\t\t<intent-filter>\n'
             '\t\t\t\t<action android:name="com.google.firebase.MESSAGING_EVENT" />\n'
             '\t\t\t</intent-filter>\n'
             '\t\t</service>\n'
             '\t\t<meta-data android:name="com.google.firebase.messaging.default_notification_icon" android:resource="@drawable/ic_stat_rostrick" />\n'
             '\t\t<meta-data android:name="com.google.firebase.messaging.default_notification_channel_id" android:value="rostrick_default" />\n'
             '\t\t<!-- RT-FB:END -->\n')
    if "</application>" not in m:
        fail("لم أجد </application> في AndroidManifest.xml")
    m = m.replace("\t</application>", block + "\t</application>", 1)
    write(manifest, m)
    print("Firebase: مفعّل (إشعارات FCM)")
    return True


def billing_enabled(cfg):
    b = cfg.get("billing")
    return isinstance(b, dict) and bool(b.get("enabled"))


def billing_public_key(cfg):
    """مفتاح الترخيص العام (Base64) من Play Console، اختياري. يُتحقق من شكله لأنه يُكتب داخل كود Java."""
    b = cfg.get("billing")
    raw = (b.get("public_key") if isinstance(b, dict) else "") or ""
    key = re.sub(r"\s+", "", str(raw))
    if not key:
        return ""
    if not re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", key):
        fail("مفتاح الترخيص (billing.public_key) يحتوي رموزاً غير صالحة؛ يجب أن يكون Base64 فقط")
    if len(key) < 200 or len(key) > 2000:
        fail("طول مفتاح الترخيص غير منطقي (%d)؛ انسخه كاملاً من Play Console" % len(key))
    try:
        import base64 as _b64
        raw_bytes = _b64.b64decode(key, validate=True)
    except Exception:  # noqa: BLE001
        fail("مفتاح الترخيص ليس Base64 صحيحاً")
    if not raw_bytes.startswith(b"\x30\x82"):
        fail("مفتاح الترخيص لا يبدو مفتاح RSA عاماً (X.509)؛ يبدأ عادةً بـ MIIB")
    return key


def apply_billing(project, cfg):
    """يفعّل الشراء داخل التطبيق (Google Play Billing) أو يتركه خارج التطبيق تماماً."""
    app_gradle = os.path.join(project, "app/build.gradle")
    g = strip_marked(read(app_gradle), "// RT-BILL:START", "// RT-BILL:END")
    if not billing_enabled(cfg):
        write(app_gradle, g)
        print("الشراء داخل التطبيق: معطّل (لا مكتبة فوترة داخل التطبيق)")
        return False
    tools = os.path.dirname(os.path.abspath(__file__))
    src = read(os.path.join(tools, "RtBillingReal.java.txt"))
    key = billing_public_key(cfg)
    if "@@RT_BILLING_KEY@@" not in src:
        fail("قالب الشراء لا يحتوي موضع مفتاح الترخيص")
    src = src.replace("@@RT_BILLING_KEY@@", key)
    write(os.path.join(project, JAVA_PKG_DIR, "RtBilling.java"), src)
    dep = ('\t// RT-BILL:START\n'
           "\timplementation \"com.android.billingclient:billing:${project.findProperty('billingVersion') ?: '8.0.0'}\"\n"
           '\t// RT-BILL:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة الفوترة في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)
    print("الشراء داخل التطبيق: مفعّل (Google Play Billing)" + (" — مع التحقق من توقيع الشراء" if key else ""))
    return True


def deeplinks_settings(cfg):
    """إعدادات الروابط العميقة: scheme مخصص (مثل myapp://) و/أو نطاقات https. يُرجع None إن لم تُفعَّل."""
    d = cfg.get("deeplinks")
    if not isinstance(d, dict) or not d.get("enabled"):
        return None
    scheme = str(d.get("scheme") or "").strip().lower()
    if scheme:
        if not re.fullmatch(r"[a-z][a-z0-9+.-]{1,30}", scheme):
            fail("اسم الـ scheme للروابط العميقة غير صالح: %r (أحرف إنجليزية صغيرة وأرقام فقط، مثل myapp)" % scheme)
        if scheme in ("http", "https", "file", "content", "intent", "javascript", "data", "about", "market", "android-app"):
            fail("اسم الـ scheme محجوز للنظام: " + scheme)
    hosts_raw = d.get("hosts") or []
    if isinstance(hosts_raw, str):
        hosts_raw = [h for h in re.split(r"[\s,]+", hosts_raw) if h]
    if not isinstance(hosts_raw, list) or len(hosts_raw) > 10:
        fail("نطاقات الروابط العميقة (deeplinks.hosts) يجب أن تكون قائمة بحد أقصى 10")
    hosts = []
    for h in hosts_raw:
        h = clean_host(str(h))
        if h and h not in hosts:
            hosts.append(h)
    if not scheme and not hosts:
        fail("الروابط العميقة مفعّلة لكن بدون scheme ولا نطاقات؛ أضف واحداً على الأقل")
    return {"scheme": scheme, "hosts": hosts, "verify": bool(d.get("verify"))}


def apply_deeplinks(project, cfg):
    """يضيف intent-filters للروابط العميقة داخل SplashActivity، ويجعل MainActivity singleTask لاستقبال الروابط أثناء تشغيل التطبيق."""
    manifest = os.path.join(project, "app/src/main/AndroidManifest.xml")
    m = strip_marked(read(manifest), "<!-- RT-DEEPLINK:START -->", "<!-- RT-DEEPLINK:END -->")
    m = m.replace('\t\t\tandroid:launchMode="singleTask"\n', "")
    st = deeplinks_settings(cfg)
    if not st:
        # أعد علامات الموضع فارغةً ليبقى الملف صالحاً لإعادة التطبيق
        anchor = '\t\t\t</intent-filter>\n\t\t</activity>\n\t</application>'
        if anchor in m:
            m = m.replace(anchor, '\t\t\t</intent-filter>\n\t\t\t<!-- RT-DEEPLINK:START -->\n\t\t\t<!-- RT-DEEPLINK:END -->\n\t\t</activity>\n\t</application>', 1)
        write(manifest, m)
        print("الروابط العميقة: معطّلة")
        return False
    lines = ['\t\t\t<!-- RT-DEEPLINK:START -->']
    if st["scheme"]:
        lines += ['\t\t\t<intent-filter>',
                  '\t\t\t\t<action android:name="android.intent.action.VIEW" />',
                  '\t\t\t\t<category android:name="android.intent.category.DEFAULT" />',
                  '\t\t\t\t<category android:name="android.intent.category.BROWSABLE" />',
                  '\t\t\t\t<data android:scheme="%s" />' % st["scheme"],
                  '\t\t\t</intent-filter>']
    if st["hosts"]:
        lines += ['\t\t\t<intent-filter%s>' % (' android:autoVerify="true"' if st["verify"] else ''),
                  '\t\t\t\t<action android:name="android.intent.action.VIEW" />',
                  '\t\t\t\t<category android:name="android.intent.category.DEFAULT" />',
                  '\t\t\t\t<category android:name="android.intent.category.BROWSABLE" />',
                  '\t\t\t\t<data android:scheme="https" />']
        lines += ['\t\t\t\t<data android:host="%s" />' % h for h in st["hosts"]]
        lines += ['\t\t\t</intent-filter>']
    lines.append('\t\t\t<!-- RT-DEEPLINK:END -->')
    block = "\n".join(lines) + "\n"
    anchor = '\t\t\t</intent-filter>\n\t\t</activity>\n\t</application>'
    if anchor not in m:
        fail("تعذّر إيجاد مكان إضافة الروابط العميقة في AndroidManifest.xml")
    m = m.replace(anchor, '\t\t\t</intent-filter>\n' + block + '\t\t</activity>\n\t</application>', 1)
    mk = '\t\t\tandroid:name=".MainActivity"\n'
    if mk not in m:
        fail("تعذّر إيجاد MainActivity في AndroidManifest.xml")
    m = m.replace(mk, mk + '\t\t\tandroid:launchMode="singleTask"\n', 1)
    write(manifest, m)
    print("الروابط العميقة: مفعّلة" + (" — scheme: %s://" % st["scheme"] if st["scheme"] else "") + (" — نطاقات: " + ", ".join(st["hosts"]) if st["hosts"] else ""))
    return True


def review_enabled(cfg):
    r = cfg.get("review")
    return isinstance(r, dict) and bool(r.get("enabled"))


def apply_review(project, cfg):
    """يفعّل طلب التقييم داخل التطبيق (Google Play In-App Review) أو يتركه خارج التطبيق تماماً."""
    app_gradle = os.path.join(project, "app/build.gradle")
    g = strip_marked(read(app_gradle), "// RT-REVIEW:START", "// RT-REVIEW:END")
    if not review_enabled(cfg):
        write(app_gradle, g)
        print("طلب التقييم داخل التطبيق: معطّل (لا مكتبة تقييم)")
        return False
    tools = os.path.dirname(os.path.abspath(__file__))
    src = read(os.path.join(tools, "RtReviewReal.java.txt"))
    write(os.path.join(project, JAVA_PKG_DIR, "RtReview.java"), src)
    dep = ('\t// RT-REVIEW:START\n'
           "\timplementation \"com.google.android.play:review:${project.findProperty('playReviewVersion') ?: '2.0.2'}\"\n"
           '\t// RT-REVIEW:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة التقييم في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)
    print("طلب التقييم داخل التطبيق: مفعّل (Google Play In-App Review)")
    return True


def resolve_output(cfg):
    out = cfg.get("output_format") or "apk"
    if out not in ("apk", "aab", "both"):
        fail("نوع المخرج غير صالح: %r (apk أو aab أو both)" % (out,))
    return out


def apply_home(project, cfg):
    """صفحة «جارٍ التحميل» الأولية داخل الـ APK (assets/home.html):
    - home_html_b64 نص → صفحة مخصصة يصممها المستخدم
    - غير موجود/null → تبقى الصفحة الافتراضية من القالب."""
    import base64
    raw = cfg.get("home_html_b64")
    if not raw:
        print("صفحة التحميل: الافتراضية")
        return
    try:
        html = base64.b64decode(raw, validate=False).decode("utf-8")
    except Exception as e:  # noqa: BLE001
        fail("home_html_b64 في config.json تالف: %s" % e)
    if not html.strip():
        fail("صفحة التحميل المخصصة فارغة")
    if len(html.encode("utf-8")) > 300 * 1024:
        fail("صفحة التحميل المخصصة أكبر من 300KB")
    # التطبيق يستدعي هاتين الدالتين لتحديث التقدم؛ نضيف نسخاً فارغة إن لم تعرّفهما الصفحة حتى لا تظهر أخطاء JS
    stubs = ""
    if "setSyncProgress" not in html:
        stubs += "window.setSyncProgress=window.setSyncProgress||function(){};"
    if "setSyncStatus" not in html:
        stubs += "window.setSyncStatus=window.setSyncStatus||function(){};"
    if stubs:
        tag = "<script>" + stubs + "</script>"
        idx = html.lower().rfind("</body>")
        html = (html[:idx] + tag + html[idx:]) if idx != -1 else (html + tag)
        print("أضفتُ دوال التقدم الفارغة تلقائياً (الصفحة لا تعرّفها).")
    write(os.path.join(project, "app/src/main/assets/home.html"), html)
    print("صفحة التحميل: مخصصة (%d بايت)" % len(html.encode("utf-8")))


def set_output(key, value):
    path = os.environ.get("GITHUB_OUTPUT")
    line = "%s=%s\n" % (key, value)
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
    else:
        print("[output]", line.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--project", required=True)
    ap.add_argument("--icon", default="")
    a = ap.parse_args()

    try:
        cfg = json.loads(read(a.config))
    except Exception as e:  # noqa: BLE001
        fail("ملف الإعدادات تالف: %s" % e)

    pkg = cfg.get("package_name")
    validate_package(pkg)

    try:
        version_code = int(cfg.get("version_code"))
    except (TypeError, ValueError):
        fail("رقم الإصدار (version_code) يجب أن يكون رقماً صحيحاً")
    if not (1 <= version_code <= 2100000000):
        fail("رقم الإصدار خارج النطاق المسموح")

    version_name = str(cfg.get("version_name") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9._+\- ]{1,40}", version_name):
        fail("اسم الإصدار (version_name) غير صالح: %r" % version_name)

    host = clean_host(cfg.get("asset_base_host"))
    if not host:
        fail("رابط الـ Worker فارغ: اضبطه في إعدادات اللوحة أولاً")

    apply_strings(a.project, cfg.get("app_name"))
    apply_colors(a.project, cfg.get("colors"))
    min_sdk, target_sdk = resolve_sdk(cfg)
    ads_on = ads_settings(cfg) is not None
    unityads_on = unity_ads_settings(cfg) is not None
    fbads_on = fb_ads_settings(cfg) is not None
    bill_on = billing_enabled(cfg)
    if (ads_on or unityads_on or fbads_on or bill_on) and min_sdk < ADS_MIN_SDK:
        print("تنبيه: الإعلانات/الشراء يتطلبان Android 6 (API %d) كحد أدنى؛ رُفع الحد الأدنى من %d." % (ADS_MIN_SDK, min_sdk))
        min_sdk = ADS_MIN_SDK
    apply_gradle(a.project, pkg, version_code, version_name, min_sdk, target_sdk)
    set_output("min_sdk", str(min_sdk))
    set_output("target_sdk", str(target_sdk))
    apply_worker_host(a.project, host)
    icon_used, icon_sha = resolve_icon(cfg, a.icon, a.project)
    apply_icon(a.project, icon_used)
    icon_style, icon_bg = apply_adaptive_icon(a.project, icon_used, cfg)
    set_output("icon_style", icon_style)
    set_output("icon_bg", icon_bg)
    apply_home(a.project, cfg)
    extra_assets_on = apply_extra_assets(a.project, cfg)
    set_output("extra_assets_enabled", "1" if extra_assets_on else "0")
    apply_permissions(a.project, cfg)
    apply_ads(a.project, cfg)
    set_output("ads_enabled", "1" if ads_on else "0")
    apply_unity_ads(a.project, cfg)
    set_output("unity_ads_enabled", "1" if unityads_on else "0")
    apply_fb_ads(a.project, cfg)
    set_output("facebook_ads_enabled", "1" if fbads_on else "0")
    fb_on = apply_firebase(a.project, cfg, pkg)
    set_output("firebase_enabled", "1" if fb_on else "0")
    apply_billing(a.project, cfg)
    set_output("billing_enabled", "1" if bill_on else "0")
    rv_on = apply_review(a.project, cfg)
    set_output("review_enabled", "1" if rv_on else "0")
    dl_on = apply_deeplinks(a.project, cfg)
    set_output("deeplinks_enabled", "1" if dl_on else "0")
    out_fmt = resolve_output(cfg)
    set_output("build_apk", "1" if out_fmt in ("apk", "both") else "0")
    set_output("build_aab", "1" if out_fmt in ("aab", "both") else "0")
    set_output("output_format", out_fmt)
    set_output("icon_used", "1" if icon_used else "0")
    set_output("icon_sha", icon_sha)

    set_output("package_name", pkg)
    set_output("version_code", str(version_code))
    set_output("version_name", version_name.replace(" ", "-"))
    set_output("asset_host", host)
    print("تم تطبيق الإعدادات: %s | %s | v%s (%d) | %s" % (cfg.get("app_name"), pkg, version_name, version_code, host))


if __name__ == "__main__":
    main()
